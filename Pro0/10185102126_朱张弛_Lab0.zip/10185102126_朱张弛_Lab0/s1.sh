mkdir foo
cd foo
echo "zhuzhangchi" >> name.txt
echo "10185102126" >> stno.txt
